const SUPABASE_URL = "https://muzyvknpztbbdthpfbya.supabase.co";
let SUPABASE_KEY = localStorage.getItem("gmm4_publishable_key") || "";
let client = SUPABASE_KEY ? supabase.createClient(SUPABASE_URL, SUPABASE_KEY) : null;
let currentUser = null;
let currentProfile = { role: "owner", full_name: "Local Owner" };
let state = { inventory: [], repairs: [], sales: [], customers: [], staff_profiles: [] };

function euro(v){return "€"+Number(v||0).toFixed(2)}
function id(){return crypto.randomUUID?crypto.randomUUID():Date.now().toString(36)+Math.random().toString(36).slice(2)}
function ticketNo(x){return x.ticket_no || ("REP-" + String(x.id || "").slice(0,8).toUpperCase())}
function invoiceNo(x){return x.invoice_no || ("INV-" + String(x.id || "").slice(0,8).toUpperCase())}
function canReport(){return ["owner","manager"].includes(currentProfile.role)}
function canDelete(){return ["owner","manager"].includes(currentProfile.role)}

document.getElementById("saveKeyBtn").addEventListener("click", () => {
  const key = document.getElementById("apiKeyInput").value.trim();
  if(!key.startsWith("sb_publishable_") && !key.startsWith("eyJ")){ alert("This does not look like a Supabase publishable/anon key."); return; }
  localStorage.setItem("gmm4_publishable_key", key);
  SUPABASE_KEY = key; client = supabase.createClient(SUPABASE_URL, SUPABASE_KEY);
  document.getElementById("keyBox").style.display = "none";
  document.getElementById("loginMessage").textContent = "Key saved. Now log in.";
});
if(SUPABASE_KEY){ document.getElementById("keyBox").style.display = "none"; }

function showApp(){
  document.getElementById("loginScreen").classList.add("hidden");
  document.getElementById("appScreen").classList.remove("hidden");
  document.getElementById("roleBadge").textContent = currentProfile.role.toUpperCase();
  document.getElementById("userInfo").textContent = `${currentProfile.full_name || "Staff"} - ${currentProfile.role}`;
  applyRoles(); renderAll();
}
function applyRoles(){
  const role = currentProfile.role;
  document.querySelectorAll("[data-roles]").forEach(el=>{ el.style.display = el.dataset.roles.split(",").includes(role) ? "" : "none"; });
  document.querySelectorAll(".restricted-report").forEach(el=>{ el.style.display = canReport() ? "" : "none"; });
}
async function login(email,password){
  if(!client){ document.getElementById("loginMessage").textContent = "Paste and save your Supabase publishable key first."; return; }
  const { data, error } = await client.auth.signInWithPassword({email,password});
  if(error){document.getElementById("loginMessage").textContent = error.message; return;}
  currentUser = data.user;
  const { data: profile, error: profileError } = await client.from("staff_profiles").select("*").eq("user_id", currentUser.id).single();
  if(profileError || !profile){ document.getElementById("loginMessage").textContent = "Login worked, but no staff profile found for this user."; return; }
  currentProfile = profile; await loadCloud(); showApp();
}
async function logout(){ if(client) await client.auth.signOut(); location.reload(); }
async function loadCloud(){
  if(!client) return;
  for(const table of ["inventory","repairs","sales","customers","staff_profiles"]){
    const { data, error } = await client.from(table).select("*").order("created_at",{ascending:false});
    if(!error && data) state[table]=data;
  }
}
async function insertRecord(table, record){
  record.id = record.id || id();
  record.created_by = currentUser?.id || null;
  record.created_at = record.created_at || new Date().toISOString();
  state[table].unshift(record); renderAll();
  if(client){
    const { error } = await client.from(table).insert(record);
    if(error) alert("Cloud save failed: " + error.message);
  }
}
async function deleteRecord(table, recId){
  if(!canDelete()){alert("Only owner or manager can delete records.");return;}
  state[table]=state[table].filter(x=>x.id!==recId); renderAll();
  if(client){
    const { error } = await client.from(table).delete().eq("id",recId);
    if(error) alert("Cloud delete failed: " + error.message);
  }
}
window.deleteRecord=deleteRecord;

function openModal(id){document.getElementById(id).classList.add("active")}
function closeModal(id){document.getElementById(id).classList.remove("active")}
window.openModal=openModal; window.closeModal=closeModal;

document.getElementById("loginForm").addEventListener("submit",e=>{e.preventDefault();const f=Object.fromEntries(new FormData(e.target).entries());login(f.email,f.password)});
document.getElementById("logoutBtn").addEventListener("click",logout);
document.getElementById("syncBtn").addEventListener("click",async()=>{await loadCloud();renderAll();alert("Sync complete")});
document.querySelectorAll(".tab").forEach(btn=>btn.addEventListener("click",()=>{document.querySelectorAll(".tab").forEach(x=>x.classList.remove("active"));document.querySelectorAll(".panel").forEach(x=>x.classList.remove("active"));btn.classList.add("active");document.getElementById(btn.dataset.tab).classList.add("active")}));
function formData(form){return Object.fromEntries(new FormData(form).entries())}

document.getElementById("repairForm").addEventListener("submit",e=>{
  e.preventDefault(); const x=formData(e.target); const rid=id();
  insertRecord("repairs",{id:rid,ticket_no:"REP-"+Date.now().toString().slice(-6),customer_name:x.customer_name,customer_phone:x.customer_phone,device:x.device,imei_serial:x.imei_serial,problem:x.problem,repair_cost:+x.repair_cost||0,deposit:+x.deposit||0,status:x.status,notes:x.notes});
  e.target.reset(); closeModal("repairModal");
});
document.getElementById("saleForm").addEventListener("submit",e=>{
  e.preventDefault(); const x=formData(e.target); const sid=id();
  insertRecord("sales",{id:sid,invoice_no:"INV-"+Date.now().toString().slice(-6),item_name:x.item_name,customer_name:x.customer_name,customer_phone:x.customer_phone,sale_amount:+x.sale_amount||0,item_cost:+x.item_cost||0,payment_method:x.payment_method,notes:x.notes});
  e.target.reset(); closeModal("saleModal");
});
document.getElementById("inventoryForm").addEventListener("submit",e=>{e.preventDefault();const x=formData(e.target);insertRecord("inventory",{category:x.category,brand:x.brand,model:x.model,variant:x.variant,serial:x.serial,buy_price:+x.buy_price||0,sell_price:+x.sell_price||0,quantity:+x.quantity||0});e.target.reset();closeModal("inventoryModal")});
document.getElementById("customerForm").addEventListener("submit",e=>{e.preventDefault();const x=formData(e.target);insertRecord("customers",{name:x.name,phone:x.phone,email:x.email,notes:x.notes});e.target.reset();closeModal("customerModal")});

function renderDashboard(){
  document.getElementById("totalStock").textContent=state.inventory.reduce((a,x)=>a+(+x.quantity||0),0);
  document.getElementById("activeRepairs").textContent=state.repairs.filter(x=>!["Collected","Cancelled"].includes(x.status)).length;
  document.getElementById("readyRepairs").textContent=state.repairs.filter(x=>x.status==="Ready").length;
  document.getElementById("totalSales").textContent=euro(state.sales.reduce((a,x)=>a+(+x.sale_amount||0),0));
  document.getElementById("totalProfit").textContent=euro(state.sales.reduce((a,x)=>a+(+x.sale_amount||0)-(+x.item_cost||0),0));
}
function renderRepairs(){
  const q=document.getElementById("repairSearch").value.toLowerCase();
  const rows=state.repairs.filter(x=>JSON.stringify(x).toLowerCase().includes(q));
  document.getElementById("repairTable").innerHTML=`<tr><th>Ticket</th><th>Customer</th><th>Phone</th><th>Device</th><th>IMEI/Serial</th><th>Problem</th><th>Cost</th><th>Deposit</th><th>Status</th><th>Actions</th></tr>${rows.map(x=>`<tr><td><strong>${ticketNo(x)}</strong></td><td>${x.customer_name||""}</td><td>${x.customer_phone||""}</td><td>${x.device||""}</td><td>${x.imei_serial||""}</td><td>${x.problem||""}<br><small>${x.notes||""}</small></td><td>${euro(x.repair_cost)}</td><td>${euro(x.deposit)}</td><td>${x.status||""}</td><td><button class="print" onclick="printRepair('${x.id}')">Print</button> ${canDelete()?`<button class="delete" onclick="deleteRecord('repairs','${x.id}')">Delete</button>`:""}</td></tr>`).join("")}`;
}
function renderSales(){
  document.getElementById("saleTable").innerHTML=`<tr><th>Invoice</th><th>Item</th><th>Customer</th><th>Phone</th><th>Amount</th><th>Cost</th><th>Profit</th><th>Payment</th><th>Actions</th></tr>${state.sales.map(x=>`<tr><td><strong>${invoiceNo(x)}</strong></td><td>${x.item_name||""}</td><td>${x.customer_name||""}</td><td>${x.customer_phone||""}</td><td>${euro(x.sale_amount)}</td><td>${canReport()?euro(x.item_cost):"Hidden"}</td><td>${canReport()?euro((+x.sale_amount||0)-(+x.item_cost||0)):"Hidden"}</td><td>${x.payment_method||""}</td><td><button class="print" onclick="printInvoice('${x.id}')">Print</button> ${canDelete()?`<button class="delete" onclick="deleteRecord('sales','${x.id}')">Delete</button>`:""}</td></tr>`).join("")}`;
}
function renderInventory(){
  const q=document.getElementById("inventorySearch").value.toLowerCase();
  const rows=state.inventory.filter(x=>JSON.stringify(x).toLowerCase().includes(q));
  document.getElementById("inventoryTable").innerHTML=`<tr><th>Category</th><th>Item</th><th>Variant</th><th>IMEI/Serial</th><th>Buy</th><th>Sell</th><th>Qty</th><th>Action</th></tr>${rows.map(x=>`<tr><td>${x.category||""}</td><td><strong>${x.brand||""} ${x.model||""}</strong></td><td>${x.variant||""}</td><td>${x.serial||""}</td><td>${euro(x.buy_price)}</td><td>${euro(x.sell_price)}</td><td>${x.quantity||0}</td><td>${canDelete()?`<button class="delete" onclick="deleteRecord('inventory','${x.id}')">Delete</button>`:""}</td></tr>`).join("")}`;
}
function renderCustomers(){
  const q=document.getElementById("customerSearch").value.toLowerCase();
  const rows=state.customers.filter(x=>JSON.stringify(x).toLowerCase().includes(q));
  document.getElementById("customerTable").innerHTML=`<tr><th>Name</th><th>Phone</th><th>Email</th><th>Notes</th><th>Action</th></tr>${rows.map(x=>`<tr><td>${x.name||""}</td><td>${x.phone||""}</td><td>${x.email||""}</td><td>${x.notes||""}</td><td>${canDelete()?`<button class="delete" onclick="deleteRecord('customers','${x.id}')">Delete</button>`:""}</td></tr>`).join("")}`;
}
function renderReports(){
  if(!canReport()) return;
  document.getElementById("cashSales").textContent=euro(state.sales.filter(x=>x.payment_method==="Cash").reduce((a,x)=>a+(+x.sale_amount||0),0));
  document.getElementById("cardSales").textContent=euro(state.sales.filter(x=>x.payment_method==="Card").reduce((a,x)=>a+(+x.sale_amount||0),0));
  document.getElementById("repairIncome").textContent=euro(state.repairs.reduce((a,x)=>a+(+x.repair_cost||0),0));
  document.getElementById("inventoryValue").textContent=euro(state.inventory.reduce((a,x)=>a+(+x.buy_price||0)*(+x.quantity||0),0));
}
function renderStaff(){
  document.getElementById("staffTable").innerHTML=`<tr><th>Name</th><th>Email</th><th>Role</th><th>Active</th></tr>${state.staff_profiles.map(x=>`<tr><td>${x.full_name||""}</td><td>${x.email||""}</td><td>${x.role||""}</td><td>${x.is_active!==false?"Yes":"No"}</td></tr>`).join("")}`;
}
function renderAll(){renderDashboard();renderRepairs();renderSales();renderInventory();renderCustomers();renderReports();renderStaff();applyRoles()}
["inventorySearch","repairSearch","customerSearch"].forEach(i=>document.getElementById(i).addEventListener("input",renderAll));

function printRepair(id){
  const x=state.repairs.find(r=>r.id===id); if(!x)return;
  const html=`<div class="print-page"><h1>Gadget Master - Repair Ticket</h1><p class="small">Ticket: <strong>${ticketNo(x)}</strong> | Date: ${new Date(x.created_at||Date.now()).toLocaleString()}</p><table><tr><td>Customer</td><td>${x.customer_name||""}</td></tr><tr><td>Phone</td><td>${x.customer_phone||""}</td></tr><tr><td>Device</td><td>${x.device||""}</td></tr><tr><td>IMEI/Serial</td><td>${x.imei_serial||""}</td></tr><tr><td>Problem</td><td>${x.problem||""}</td></tr><tr><td>Repair Cost</td><td>${euro(x.repair_cost)}</td></tr><tr><td>Deposit</td><td>${euro(x.deposit)}</td></tr><tr><td>Balance</td><td>${euro((+x.repair_cost||0)-(+x.deposit||0))}</td></tr><tr><td>Status</td><td>${x.status||""}</td></tr><tr><td>Notes</td><td>${x.notes||""}</td></tr></table><p class="small">Please keep this ticket for collection. Gadget Master is not responsible for data loss unless backup service is requested.</p></div>`;
  printHtml(html);
}
function printInvoice(id){
  const x=state.sales.find(s=>s.id===id); if(!x)return;
  const html=`<div class="print-page"><h1>Gadget Master - Invoice</h1><p class="small">Invoice: <strong>${invoiceNo(x)}</strong> | Date: ${new Date(x.created_at||Date.now()).toLocaleString()}</p><table><tr><td>Customer</td><td>${x.customer_name||""}</td></tr><tr><td>Phone</td><td>${x.customer_phone||""}</td></tr><tr><td>Item / Service</td><td>${x.item_name||""}</td></tr><tr><td>Amount Paid</td><td>${euro(x.sale_amount)}</td></tr><tr><td>Payment Method</td><td>${x.payment_method||""}</td></tr><tr><td>Notes</td><td>${x.notes||""}</td></tr></table><p class="small">Thank you for shopping with Gadget Master.</p></div>`;
  printHtml(html);
}
function printHtml(html){
  const div=document.createElement("div"); div.innerHTML=html; document.body.appendChild(div);
  window.print(); setTimeout(()=>div.remove(),500);
}
window.printRepair=printRepair; window.printInvoice=printInvoice;
